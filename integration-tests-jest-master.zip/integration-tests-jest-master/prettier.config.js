module.exports = {
  singleQuote: true,
  trailingComma: 'none',
  arrowParens: 'avoid'
};
